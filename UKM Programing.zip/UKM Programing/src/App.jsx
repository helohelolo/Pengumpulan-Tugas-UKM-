import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [number1 , setNumber1] = useState({num1 : 0});
  const [number2 , setNumber2] = useState({num2 : 0});

  return (
    <>
      <form>
      <input value={number1.num1} onChange={e => {
        setNumber1({
          ...number1,
          num1 : e.target.value
        });
      }} />
      <br />
      <input value={number2.num2} onChange={e => {
        setNumber2({
          ...number2,
          num2 : e.target.value
        });
      }} />
      <p>Hasil : {parseInt(number1.num1) + parseInt(number2.num2)}</p>
      </form>
    </>
  )
}

export default App
